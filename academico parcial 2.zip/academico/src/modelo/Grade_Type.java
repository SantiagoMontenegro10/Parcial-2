package modelo;

import db.connection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Grade_Type {
    private int id;
    private String name;
    private double weight;

    public Grade_Type(int id, String name, double weight) {
        this.id = id;
        this.name = name;
        this.weight = weight;
    }

    // Getters
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public double getWeight() {
        return weight;
    }

    // Insertar un nuevo tipo de calificación
    public static void insertGradeType(Grade_Type gradeType) {
        Connection con = connection.getConnection();

        String sql = "INSERT INTO grade_type (id, name, weight) VALUES (?, ?, ?)";

        try (PreparedStatement statement = con.prepareStatement(sql)) {
            statement.setInt(1, gradeType.getId());
            statement.setString(2, gradeType.getName());
            statement.setDouble(3, gradeType.getWeight());

            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Obtener todos los tipos de calificación
    public static List<Grade_Type> getAllGradeTypes() {
        Connection con = connection.getConnection();
        List<Grade_Type> gradeTypes = new ArrayList<>();

        String sql = "SELECT * FROM grade_type";

        try (PreparedStatement statement = con.prepareStatement(sql)) {
            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                Grade_Type gradeType = new Grade_Type(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getDouble("weight")
                );
                gradeTypes.add(gradeType);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return gradeTypes;
    }
}
