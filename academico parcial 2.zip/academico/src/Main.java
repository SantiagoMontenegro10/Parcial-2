import controlador.CourseController;
import controlador.EnrollmentController;
import controlador.GradeController;
import controlador.Grade_TypeController;
import controlador.StudentController;
import controlador.TeacherController;
import db.connection; // Asegúrate de que la clase esté correctamente importada
import modelo.Course;
import modelo.Enrollment;
import modelo.Grade;
import modelo.Grade_Type;
import modelo.Student;
import modelo.Teacher;
import vista.ViewCourse;
import vista.ViewEnrollment;
import vista.ViewGrade;
import vista.ViewGrade_Type;
import vista.ViewStudent;
import vista.ViewTeacher;

public class Main {
    public static void main(String[] args) {
        System.out.println("Bienvenido a nuestro sistema académico!");

        // Establecer conexión a la base de datos
        connection.getConnection();

        // Inicializar vistas
        ViewStudent viewStudent = new ViewStudent();
        ViewTeacher viewTeacher = new ViewTeacher();
        ViewCourse viewCourse = new ViewCourse();
        ViewEnrollment viewEnrollment = new ViewEnrollment();
        ViewGrade viewGrade = new ViewGrade();
        ViewGrade_Type viewGradeType = new ViewGrade_Type();

        // Inicializar controladores
        StudentController studentController = new StudentController(viewStudent);
        TeacherController teacherController = new TeacherController(viewTeacher);
        CourseController courseController = new CourseController(viewCourse);
        EnrollmentController enrollmentController = new EnrollmentController(viewEnrollment);
        GradeController gradeController = new GradeController(viewGrade);
        Grade_TypeController gradeTypeController = new Grade_TypeController(viewGradeType);

        // Inicializar objetos estudiante
        Student[] students = {
                new Student(13345, "Daniel", "daniel@gmail.com"),
                new Student(13346, "Matias", "matias@gmail.com"),
                new Student(13347, "Camila", "camila@gmail.com"),
                new Student(13348, "Leo", "leo@gmail.com"),
                new Student(13349, "Pablo", "pablo@gmail.com"),
                new Student(13350, "Maria", "maria@gmail.com"),
                new Student(13351, "Mateo", "mateo@gmail.com"),
                new Student(13352, "Santiago", "santiago@gmail.com"),
                new Student(13353, "Alejandra", "alejandra@gmail.com"),
                new Student(13354, "Isabella", "isabella@gmail.com")
        };

        // Guardar estudiantes en la base de datos
        for (Student student : students) {
            studentController.insertNewStudent(student);
        }

        // Mostrar datos en las vistas
        studentController.displayAllStudents();

        // Inicializar y guardar profesor
        Teacher newTeacher = new Teacher(1535, "Pablo", "Ciencias Sociales");
        teacherController.insertNewTeacher(newTeacher);
        teacherController.displayAllTeachers();

        // Inicializar y guardar curso
        Course newCourse = new Course(1535, "Historia", "...", true, newTeacher.getId());
        courseController.insertNewCourse(newCourse);
        courseController.displayAllCourses();

        // Inicializar y guardar tipos de calificación
        Grade_Type gradeType1 = new Grade_Type(1, "Examen", 50.0);
        Grade_Type gradeType2 = new Grade_Type(2, "Tarea", 30.0);
        Grade_Type gradeType3 = new Grade_Type(3, "Proyecto", 20.0);

        gradeTypeController.insertNewGradeType(gradeType1);
        gradeTypeController.insertNewGradeType(gradeType2);
        gradeTypeController.insertNewGradeType(gradeType3);

        // Mostrar tipos de calificación
        gradeTypeController.displayAllGradeTypes();

        // Inicializar y guardar inscripciones
        Enrollment enrollment1 = new Enrollment(1, students[0].getId(), newCourse.getId());
        Enrollment enrollment2 = new Enrollment(2, students[1].getId(), newCourse.getId());

        enrollmentController.insertNewEnrollment(enrollment1);
        enrollmentController.insertNewEnrollment(enrollment2);

        // Mostrar inscripciones
        enrollmentController.displayAllEnrollments();

        // Inicializar y guardar calificaciones
        Grade grade1 = new Grade(1, enrollment1.getId(), gradeType1.getId(), 4.5);
        Grade grade2 = new Grade(2, enrollment2.getId(), gradeType2.getId(), 3.8);

        gradeController.insertNewGrade(grade1);
        gradeController.insertNewGrade(grade2);

        // Mostrar calificaciones
        gradeController.displayAllGrades();

        // Ejecutar consulta para obtener calificaciones por curso
        System.out.println("Calificaciones del curso 123:");
        gradeController.displayGradesByCourse(123); // Llama al nuevo metodo para mostrar las calificaciones del curso
    }
}
