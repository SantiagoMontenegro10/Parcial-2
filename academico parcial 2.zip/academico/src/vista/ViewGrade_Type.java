package vista;

import modelo.Grade_Type;

import java.util.List;

public class ViewGrade_Type {

    // Mostrar mensaje de éxito al agregar un tipo de calificación
    public void showGradeTypeAddedMessage(Grade_Type gradeType) {
        System.out.println("Grade type added successfully: ID " + gradeType.getId() + ", Name " + gradeType.getName() + ", Weight " + gradeType.getWeight());
    }

    // Mostrar todos los tipos de calificación
    public void displayGradeTypes(List<Grade_Type> gradeTypes) {
        System.out.println("Grade Types List:");
        for (Grade_Type gradeType : gradeTypes) {
            System.out.println("ID: " + gradeType.getId() + ", Name: " + gradeType.getName() + ", Weight: " + gradeType.getWeight());
        }
    }

    // Mostrar mensaje cuando no hay tipos de calificación
    public void showNoGradeTypesMessage() {
        System.out.println("No grade types available.");
    }

    // Mostrar mensaje de error
    public void showError(String message) {
        System.out.println("Error: " + message);
    }
}
