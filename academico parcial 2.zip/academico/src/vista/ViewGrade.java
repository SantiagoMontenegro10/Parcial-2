package vista;

import modelo.Grade;

import java.util.List;

public class ViewGrade {

    // Mostrar mensaje de éxito al agregar una calificación
    public void showGradeAddedMessage(Grade grade) {
        System.out.println("Grade added successfully: " + grade.getGrade());
    }

    // Mostrar todas las calificaciones
    public void displayGrades(List<Grade> grades) {
        System.out.println("Grades List:");
        for (Grade grade : grades) {
            System.out.println("ID: " + grade.getId() + ", Enrollment ID: " + grade.getEnrollmentId()
                    + ", Grade Type ID: " + grade.getGradeTypeId() + ", Grade: " + grade.getGrade());
        }
    }

    // Mostrar mensaje cuando no hay calificaciones
    public void showNoGradesMessage() {
        System.out.println("No grades available.");
    }

    // Mostrar mensaje de error
    public void showError(String message) {
        System.out.println("Error: " + message);
    }
}
