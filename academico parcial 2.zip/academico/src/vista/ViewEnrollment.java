package vista;

import modelo.Enrollment;

import java.util.List;

public class ViewEnrollment {

    // Mostrar mensaje de éxito al agregar una inscripción
    public void showEnrollmentAddedMessage(Enrollment enrollment) {
        System.out.println("Enrollment added successfully: Student ID " + enrollment.getStudentId() + " in Course ID " + enrollment.getCourseId());
    }

    // Mostrar todas las inscripciones
    public void displayEnrollments(List<Enrollment> enrollments) {
        System.out.println("Enrollments List:");
        for (Enrollment enrollment : enrollments) {
            System.out.println("ID: " + enrollment.getId() + ", Student ID: " + enrollment.getStudentId()
                    + ", Course ID: " + enrollment.getCourseId());
        }
    }

    // Mostrar mensaje cuando no hay inscripciones
    public void showNoEnrollmentsMessage() {
        System.out.println("No enrollments available.");
    }

    // Mostrar mensaje de error
    public void showError(String message) {
        System.out.println("Error: " + message);
    }
}
