package controlador;

import modelo.Grade;
import vista.ViewGrade;

import java.util.List;

public class GradeController {
    private ViewGrade view;

    // Constructor
    public GradeController(ViewGrade view) {
        this.view = view;
    }

    // Método para insertar una nueva calificación
    public void insertNewGrade(Grade grade) {
        try {
            Grade.insertGrade(grade);
            view.showGradeAddedMessage(grade);
        } catch (Exception e) {
            view.showError("Error inserting grade: " + e.getMessage());
        }
    }

    // Método para mostrar todas las calificaciones
    public void displayAllGrades() {
        try {
            List<Grade> grades = Grade.getAllGrades();
            if (grades.isEmpty()) {
                view.showNoGradesMessage();
            } else {
                view.displayGrades(grades);
            }
        } catch (Exception e) {
            view.showError("Error retrieving grades: " + e.getMessage());
        }
    }

    public void displayGradesByCourse(int courseId) {
        try {
            List<Grade> grades = Grade.getGradesByCourse(courseId); // Asumiendo que este método ya está definido en el modelo Grade
            if (grades.isEmpty()) {
                view.showNoGradesMessage();
            } else {
                view.displayGrades(grades);
            }
        } catch (Exception e) {
            view.showError("Error retrieving grades for course " + courseId + ": " + e.getMessage());
        }
    }
}
