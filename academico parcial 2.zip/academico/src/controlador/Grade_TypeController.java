package controlador;

import modelo.Grade_Type;
import vista.ViewGrade_Type;

import java.util.List;

public class Grade_TypeController {
    private ViewGrade_Type view;

    // Constructor
    public Grade_TypeController(ViewGrade_Type view) {
        this.view = view;
    }

    // Metodo para insertar un nuevo tipo de calificación
    public void insertNewGradeType(Grade_Type gradeType) {
        try {
            Grade_Type.insertGradeType(gradeType);
            view.showGradeTypeAddedMessage(gradeType);
        } catch (Exception e) {
            view.showError("Error inserting grade type: " + e.getMessage());
        }
    }

    // Metodo para mostrar todos los tipos de calificación
    public void displayAllGradeTypes() {
        try {
            List<Grade_Type> gradeTypes = Grade_Type.getAllGradeTypes();
            if (gradeTypes.isEmpty()) {
                view.showNoGradeTypesMessage();
            } else {
                view.displayGradeTypes(gradeTypes);
            }
        } catch (Exception e) {
            view.showError("Error retrieving grade types: " + e.getMessage());
        }
    }
}
