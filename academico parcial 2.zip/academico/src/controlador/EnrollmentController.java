package controlador;

import modelo.Enrollment;
import vista.ViewEnrollment;

import java.util.List;

public class EnrollmentController {
    private ViewEnrollment view;

    // Constructor
    public EnrollmentController(ViewEnrollment view) {
        this.view = view;
    }

    // Método para insertar una nueva inscripción
    public void insertNewEnrollment(Enrollment enrollment) {
        try {
            Enrollment.insertEnrollment(enrollment);
            view.showEnrollmentAddedMessage(enrollment);
        } catch (Exception e) {
            view.showError("Error inserting enrollment: " + e.getMessage());
        }
    }

    // Método para mostrar todas las inscripciones
    public void displayAllEnrollments() {
        try {
            List<Enrollment> enrollments = Enrollment.getAllEnrollments();
            if (enrollments.isEmpty()) {
                view.showNoEnrollmentsMessage();
            } else {
                view.displayEnrollments(enrollments);
            }
        } catch (Exception e) {
            view.showError("Error retrieving enrollments: " + e.getMessage());
        }
    }
}
